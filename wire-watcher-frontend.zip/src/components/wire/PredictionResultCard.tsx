import { Database, Info } from "lucide-react";

import { Panel } from "@/components/wire/Panel";
import type { PredictRequest, PredictResponse } from "@/types/wire-watcher";
import { formatFrequencyRange, formatLocation, formatProbability } from "@/utils/format";
import { cn } from "@/lib/utils";

export function PredictionResultCard({
  result,
  request,
  receivedAt,
}: {
  result: PredictResponse;
  request: PredictRequest;
  receivedAt: string;
}) {
  const available = result.available;

  return (
    <div className="space-y-4">
      <section
        className={cn(
          "panel relative overflow-hidden px-5 py-6",
          available ? "border-available/35" : "border-occupied/35",
        )}
      >
        <span
          className={cn(
            "pointer-events-none absolute -right-16 -top-16 size-56 rounded-full blur-3xl",
            available ? "bg-available/12" : "bg-occupied/12",
          )}
        />
        <p className="label-caps">Model output</p>
        <p
          className={cn(
            "font-display mt-2 text-4xl font-semibold tracking-tight sm:text-5xl",
            available ? "text-available" : "text-occupied",
          )}
        >
          {available ? "AVAILABLE" : "NOT AVAILABLE"}
        </p>
        <p className="numeric mt-2 text-sm text-muted-foreground">
          prediction = {result.prediction} · available = {String(result.available)}
        </p>

        <dl className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <dt className="label-caps">Probability</dt>
            <dd className="numeric mt-1 text-xl">{formatProbability(result.probability)}</dd>
            <dd className="numeric text-xs text-muted-foreground">raw: {result.probability}</dd>
          </div>
          <div>
            <dt className="label-caps">Frequency</dt>
            <dd className="numeric mt-1 text-xl">
              {formatFrequencyRange(request.start_frequency_mhz, request.end_frequency_mhz)}
            </dd>
            <dd className="numeric text-xs text-muted-foreground">
              bandwidth {request.bandwidth_mhz} MHz
            </dd>
          </div>
          <div>
            <dt className="label-caps">Location</dt>
            <dd className="mt-1 text-xl">{formatLocation(request.city, request.state)}</dd>
            <dd className="text-xs text-muted-foreground">{request.service_type}</dd>
          </div>
          <div>
            <dt className="label-caps">Timestamp (client)</dt>
            <dd className="numeric mt-1 text-sm">{receivedAt}</dd>
            <dd className="text-xs text-muted-foreground">
              Backend response contains no timestamp field.
            </dd>
          </div>
        </dl>
      </section>

      <div className="rounded-lg border border-warning/35 bg-warning/8 px-4 py-3 text-sm">
        <p className="flex items-center gap-2 font-semibold text-warning">
          <Database className="size-4" /> Database save status — not reported
        </p>
        <p className="mt-1 text-foreground/85">
          Prediction completed. The response from <span className="numeric">POST /api/predict</span>{" "}
          does not include a database write confirmation, so this dashboard cannot claim the record
          was saved to MySQL. Add a boolean such as{" "}
          <span className="numeric">saved_to_database</span> (plus an error message on failure) to
          the response and this card will report it.
        </p>
      </div>

      <Panel title="features_used" subtitle="Exact feature values the model used, as returned by the API.">
        <div className="grid gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(result.features_used ?? {}).map(([key, value]) => (
            <div key={key} className="flex items-baseline justify-between gap-3 border-b border-border/50 py-1.5">
              <span className="numeric text-xs text-muted-foreground">{key}</span>
              <span className="numeric text-sm">{String(value)}</span>
            </div>
          ))}
        </div>
      </Panel>

      <p className="flex items-start gap-2 text-xs text-muted-foreground">
        <Info className="mt-0.5 size-3.5 shrink-0" />
        Output is an ML-based availability prediction trained on synthetic data — not a real-time
        spectrum measurement or a guarantee of availability.
      </p>
    </div>
  );
}
