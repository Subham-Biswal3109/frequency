/**
 * Types mirroring the EXISTING Flask API contract for Wire Watcher.
 * Field names come from the running backend (POST /api/predict) and must not be renamed.
 */

export interface PredictRequest {
  start_frequency_mhz: number;
  end_frequency_mhz: number;
  bandwidth_mhz: number;
  hour_of_day: number;
  day_of_week: number;
  signal_power_dbm: number;
  noise_floor_dbm: number;
  snr_db: number;
  state: string;
  city: string;
  service_type: string;
  region?: string;
  latitude?: number;
  longitude?: number;
}

/** Exact successful response shape of POST /api/predict. */
export interface PredictResponse {
  prediction: number;
  available: boolean;
  probability: number;
  features_used: Record<string, string | number>;
}

/**
 * Normalized view of a stored prediction record coming from GET /api/predictions.
 * The backend row shape is read tolerantly: any field the backend does not
 * return stays `null` and is rendered as "—" (never faked).
 */
export interface PredictionRecord {
  id: string;
  start_frequency_mhz: number | null;
  end_frequency_mhz: number | null;
  bandwidth_mhz: number | null;
  city: string | null;
  state: string | null;
  service_type: string | null;
  available: boolean | null;
  probability: number | null;
  timestamp: string | null;
  raw: Record<string, unknown>;
}

/** Shape of GET /api/health once the backend exposes it. */
export interface HealthResponse {
  status?: string;
  api?: string;
  model?: string;
  model_loaded?: boolean;
  database?: string;
  database_connected?: boolean;
  [key: string]: unknown;
}

export type ApiErrorKind =
  | "network"
  | "timeout"
  | "validation"
  | "server"
  | "malformed"
  | "not_implemented";
